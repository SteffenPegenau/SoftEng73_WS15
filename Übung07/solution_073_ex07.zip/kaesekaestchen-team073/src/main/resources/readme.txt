Haha! Wieder mal eine README-Datei völlig ohne Inhalt, 
die du umsonst gelesen hast! :-P

