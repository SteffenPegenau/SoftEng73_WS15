package se_ex01;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;
import java.util.stream.Stream;

public class Menu {
	private ControlInputs police = new ControlInputs();

	public Menu() {
	}

	private void printReadMe() {
		StringBuilder result = new StringBuilder("");
		URL url = this.getClass().getResource("readme.txt");
		try {
			System.out.println(url.toURI());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		File testWsdl = new File(url.getFile());
	}

	private void print() {
		System.out.println();
		System.out.println("---------------------------------------------");
		System.out.println("------------------->MENU<-------------------");
		System.out.println("---------------------------------------------");
		System.out.println();
		System.out.println("Please choose between: ");
		System.out.println();
		System.out.println("Hint: the AIMinMax is more difficult than AIRandom. ");
		System.out.println();
		System.out.println("\tMode 1: Game against at least one human (With optional KIMinMaxSupport)");
		System.out.println("\tMode 2: Player vs Player with AIRandom support");
		System.out.println("\tMode 3: Player vs Player with AIMinMax support");
		System.out.println("\tMode 4: Player vs AIRandom (Easy Mode)");
		System.out.println("\tMode 5: Player vs AIMinMax (Hard Mode)");
		System.out.println();
		System.out.println("\tMode 0: Print ReadMe");
		System.out.println();
	}

	public PlayingMode promptForTheMenueSettings() {
		int input = -1;

		while (input <= 0) {
			print();
			input = police.getNumber("Please enter a number between 1 and 5 to choose your mode",
					"Please enter a number between 1 - 5");

			switch (input) {
			case 0:
				printReadMe();
				break;
			case 1:
				return PlayingMode.AgainstHumans;
			case 2:
				return PlayingMode.AIRandomSupport;
			case 3:
				return PlayingMode.AIMinMaxSupport;
			case 4:
				return PlayingMode.AgainstAIRandom;
			case 5:
				return PlayingMode.AgainstAIMinMax;
			}
		}
		// Kann eigentlich nicht passieren, da Wert oben geprueft wird
		return PlayingMode.AgainstHumans;
	}
}
