package se_ex01;

public enum PlayingMode {
	AgainstHumans, AIRandomSupport, AIMinMaxSupport, AgainstAIRandom, AgainstAIMinMax
}
