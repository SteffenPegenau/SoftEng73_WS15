package old;

public enum PlayingMode {
	AgainstHumans, AIRandomSupport, AIMinMaxSupport, AgainstAIRandom, AgainstAIMinMax
}
