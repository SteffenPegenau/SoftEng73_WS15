package Parser;

public class PostfixParser {
	public static Expression process(String[] elements) {
		Expression head = null;
		
		String[] e = { "a", "b", "&" };
		
		for (String s : e) {
			
		}
		
		return head;
	}
}
