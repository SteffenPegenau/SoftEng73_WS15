package Parser;

public enum Type {
	VAR,
	BOOLEAN_OP
}
