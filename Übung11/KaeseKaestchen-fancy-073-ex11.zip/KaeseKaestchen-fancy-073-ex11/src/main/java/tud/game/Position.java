package tud.game;

public class Position {

	private Strategy strategy;

	private int row;
	private int col;

	public int getRow() {
		return row;
	}

	public int getCol() {
		return col;
	}

	public Strategy getStrategy() {

		return strategy;
	}

	public void setStrategy(Strategy t) {

		this.strategy = t;
	}

	public Position(int row, int col) {
		this.row = row;
		this.col = col;
		this.strategy = null;
	}

}
