package tud.game;

public interface Strategy {
	
	public void DoAction(String nameame, int position, Board board);

}
