package tud.game;

public class Vulcano implements Strategy {

	@Override
	public void DoAction(String name, int position, Board board) {
		int row = board.getRow(position);
		int col = board.getCol(position);

		// Felder in der Umgebung haben eine p=0.5 Chance zerstört zu werden

		if (row % 2 == 0) {
			if (col + 2 < board.board[row].length && board.board[row][col + 2].equals("-"))
				board.board[row][col + 2] = (Math.random() > 0.5) ? destroy(board, row, col + 2) : "-";

			if (col - 2 > 0 && board.board[row][col - 2].equals("-"))
				board.board[row][col - 2] = (Math.random() > 0.5) ? destroy(board, row, col - 2) : "-";

			if (col + 1 < board.board[row].length && row + 1 < board.board.length
					&& board.board[row + 1][col + 1].equals("|"))
				board.board[row + 1][col + 1] = (Math.random() > 0.5) ? destroy(board, row + 1, col + 1) : "|";

			if (col - 1 >= 0 && row + 1 < board.board.length && board.board[row + 1][col - 1].equals("|"))
				board.board[row + 1][col - 1] = (Math.random() > 0.5) ? destroy(board, row + 1, col - 1) : "|";

			if (col + 1 < board.board[row].length && row - 1 >= 0 && board.board[row - 1][col + 1].equals("|"))
				board.board[row - 1][col + 1] = (Math.random() > 0.5) ? destroy(board, row - 1, col + 1) : "|";

			if (col - 1 >= 0 && row - 1 >= 0 && board.board[row - 1][col - 1].equals("|"))
				board.board[row - 1][col - 1] = (Math.random() > 0.5) ? destroy(board, row - 1, col - 1) : "|";

		} else {
			if (row + 2 < board.board.length && board.board[row + 2][col].equals("|"))
				board.board[row + 2][col] = (Math.random() > 0.5) ? destroy(board, row + 2, col) : "|";

			if (row - 2 > 0 && board.board[row - 2][col].equals("|"))
				board.board[row - 2][col] = (Math.random() > 0.5) ? destroy(board, row - 2, col) : "|";

			if (col + 1 < board.board[row].length && row + 1 < board.board.length
					&& board.board[row + 1][col + 1].equals("-"))
				board.board[row + 1][col + 1] = (Math.random() > 0.5) ? destroy(board, row + 1, col + 1) : "-";

			if (col - 1 >= 0 && row + 1 < board.board.length && board.board[row + 1][col - 1].equals("-"))
				board.board[row + 1][col - 1] = (Math.random() > 0.5) ? destroy(board, row + 1, col - 1) : "-";

			if (col + 1 < board.board[row].length && row - 1 >= 0 && board.board[row - 1][col + 1].equals("-"))
				board.board[row - 1][col + 1] = (Math.random() > 0.5) ? destroy(board, row - 1, col + 1) : "-";

			if (col - 1 >= 0 && row - 1 >= 0 && board.board[row - 1][col - 1].equals("-"))
				board.board[row - 1][col - 1] = (Math.random() > 0.5) ? destroy(board, row - 1, col - 1) : "-";

		}
	}

	private String destroy(Board board, int r, int c) {
		board.numberOfFreeFields++;
		return board.getNewPosition(r, c);
	}

}
