package tud.game;

public class Flooding implements Strategy {

	@Override
	public void DoAction(String name, int position, Board board) {
		int row = board.getRow(position);
		int col = board.getCol(position);
		if (row % 2 == 0) {
			for (int i = 0; i < board.fieldLen * 2 + 1; i++) {
				if (i != row) {
					if (board.board[i][col].equals("-")) {
						board.board[i][col] = board.getNewPosition(i, col);
						board.numberOfFreeFields++;
					}
				}
			}
		} else {
			for (int i = 0; i < board.fieldLen * 2 + 1; i++) {
				if (i != col) {
					if (board.board[row][i].equals("|")) {
						board.board[row][i] = board.getNewPosition(row, i);
						board.numberOfFreeFields++;
					}
				}
			}
		}
	}
}
