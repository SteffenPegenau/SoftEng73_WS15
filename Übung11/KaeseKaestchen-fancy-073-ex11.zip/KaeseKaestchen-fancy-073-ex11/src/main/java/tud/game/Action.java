package tud.game;

public enum Action {
	
	NextTurn, Again

}
