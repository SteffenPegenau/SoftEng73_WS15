package tud.game.ai;

public enum MiniMax {
	MIN, MAX
}
